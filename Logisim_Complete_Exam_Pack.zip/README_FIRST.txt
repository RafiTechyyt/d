LOGISIM EVOLUTION - EXPANDED EXAM CIRCUIT PACK
===============================================

This is a broad collection based on the Digital Electronics / Logic Design
lab topics you mentioned.

GATE-LEVEL CIRCUITS (actual gate components and wire records):
01 Basic logic gates
02 Half adder
03 Full adder
04 Half subtractor
05 Full subtractor
06 SOP example F = B'C + AB
07 POS example F = (A+B)(B'+C)
08 2:1 MUX
09 4:1 MUX
10 1:2 DEMUX
11 1:4 DEMUX
12 2:4 decoder
13 Binary to Gray
14 Gray to Binary
15 4:2 encoder (one-hot)
16 4:2 priority encoder
17 1-bit comparator
18 4-bit parity generator
19 2-bit comparator
20 8:1 MUX
22 SR latch (NOR cross-coupled)

MEMORY COMPONENT PROJECTS:
23 D flip-flop component
24 JK flip-flop component
25 T flip-flop component
26 3-bit counter component (set width/max in component attributes)
27 Mod-10 counter component (set width=4, max=9)

IMPORTANT LIMITATIONS / CHECK BEFORE EXAM:
- The combinational .circ files contain gate components and wire records.
  They are generated as Logisim Evolution XML and parsed for well-formedness.
- The memory-component projects contain native Logisim Memory components,
  but their labelled input/output pins are not yet wired to the component pins.
  Connect the actual component pin dots in your installed version before use.
- The D latch project exposes gated S/R signals; it is not a finished latch.
- This environment does not have Logisim Evolution installed, so I cannot
  honestly claim that every file has been opened and simulated here.

HOW TO OPEN:
1. Extract the ZIP.
2. Open any .circ file in Logisim Evolution.
3. Use Poke Tool to toggle input pins.
4. Observe output pins.
5. For sequential circuits, use Simulate > Manual Tick or enable Auto-Tick
   after wiring the clock and component pins.

For the 3-bit synchronous up/down counter, use the 3-bit Counter component
with its UpDown control input. Check the component pin map in your version.
